# Handoff: Bošán admin system — visual redesign

## Overview
Bošán ("NEXT") is the internal admin system of a scouts group. This package proposes a
**visual refresh** of the existing app that keeps every screen, feature and data flow exactly
as they are today, and only changes the styling so the UI consistently applies the group's
brand identity (defined in the group's colour manual).

The redesign is **static** — no new features, no restructured navigation. Same pages, same
fields, same actions; just brand-consistent colour, typography, shape and component styling.

Scope covered in this package:
- Nástěnka (dashboard)
- Přehled akcí (events list)
- Oddíly / Databáze (teams / member database)
- Detail akce (event detail) — all five subpages: Info, Účastníci, Problémy, Účtování, Report
- Galerie — album (photo album detail)
- Mobile views for: dashboard, event detail, oddíly, album

## About the Design Files
The file in this bundle — `Bošán návrhy.dc.html` — is a **design reference created in HTML**.
It is a before/after review board (original screenshot on the left, redesigned mock on the
right, plus annotation cards explaining each change). It is **not production code to copy
directly**.

The task is to **apply these visual changes to the existing Bošán codebase** using its
established framework, component library and patterns. Recreate the *look* (colour, type,
spacing, shape, component treatments) shown in the "Návrh" (proposal) mocks — do not port the
HTML verbatim, and do not change functionality, routing or data.

The "Původní" (original) images are screenshots of the current live app for reference.

## Fidelity
**High-fidelity.** Colours, typography, spacing, radii and component treatments are final and
specified below. Recreate them faithfully using the codebase's existing UI primitives. Where a
measurement isn't listed, match the proportions in the mock and follow the spacing scale below.

---

## Core design principles (apply everywhere)
These four rules drive every screen change. When in doubt, follow these:

1. **"Žlutá na modré" (yellow on blue) is the primary identity.** Top app bar / headers are
   brand blue `#2a3478` with white/yellow content. Use it prominently and consistently.
2. **The four brand colours are TEAM (oddíl) colours — reserve them for team identity.**
   Blue, yellow, green and red also identify the children's teams, so they must be used to
   mark teams (oddíl badges on members, events, database), NOT spent as generic decoration.
   General/neutral UI chrome stays **blue + yellow + neutral greys**. This is the single most
   important rule.
3. **Rounded, organic shapes.** Cards, tiles, buttons and inputs use generous border-radius and
   soft shadows instead of hard 1–2px black borders.
4. **Brand typography.** Display font "ŠÁN" (the group's playful rounded headline face) for
   headings; a clean humanist sans for body. In the mock, ŠÁN is approximated with **Baloo 2**
   and body is **Nunito Sans** — substitute the real ŠÁN font in production if available.

---

## Design Tokens

### Colours
| Token | Hex | Use |
|---|---|---|
| Blue (primary) | `#2a3478` | app bar, headers, primary text accents, primary hero cards, team "4" |
| Blue mid | `#4a58b0` | secondary blue accents |
| Blue tint | `#eef1fb` | tile background (Akce), table header bg |
| Blue tint 2 | `#e3e8fa` | status pills ("Připravovaná"), info chips |
| Yellow (accent) | `#e28f26` | logo mark, primary action buttons, active nav highlight, team "22" |
| Yellow tint | `#fdf1de` | active sidebar item bg, warning pill bg |
| Yellow deep text | `#b9720f` | text/icon on yellow-tint pills |
| Green | `#799f3d` | team colour (oddíl 3, 6), team avatars |
| Green tint | `#eef4e4` | tile background (Wiki) |
| Red | `#d2232a` | team colour (oddíl 5), destructive actions, "Bez vedoucího", delete icons |
| Red tint | `#fbe7e7` | tile background (Databáze) |
| Ink | `#1f2430` | body text, "Klub přátel" badge, device bezel |
| Muted | `#6b7185` | secondary text, inactive nav |
| Line | `#e6e8f0` | hairline dividers, borders |
| Neutral badge | `#d7dbe6` / text `#6b7185` | teams with no assigned brand colour (e.g. "7") |
| Neutral pill | `#eef1f6` / text `#6b7185` | non-team status pills (roles, "Bez problémů", "Nepublikováno") |
| Paper | `#f6f7fb` | app content background |
| White | `#ffffff` | cards, sidebar |

> Team colour map used in the mocks (confirm against real data): oddíl **3 = green**,
> **4 = blue**, **5 = red**, **6 = green**, **7 = neutral grey** (no brand colour assigned),
> **22 = yellow**, **Klub přátel (KP) = ink/black**. Roles (Vedoucí/Instruktor/Dítě) are NOT
> teams → neutral grey pills.

### Typography
- **Headings:** ŠÁN (production) / **Baloo 2** (mock), weight 700–800.
- **Body/UI:** **Nunito Sans**, 400 / 600 / 700 / 800.
- Sizes seen: page H1 (desktop mock) ~26–28px/800; section headings 18–22px/800; body 13–15px;
  labels/meta 11–13px; pills 11–12px/700–800. On production web keep body ≥14px.

### Spacing
Roughly an 8px-ish scale: gaps and padding cluster at 3, 6, 8, 10, 12, 14, 16, 18, 20, 22px.
Card padding 14–20px; grid gaps 10–14px; section vertical rhythm ~60–88px in the review board
(that rhythm is board-only — use normal in-app spacing in production).

### Border radius
- Buttons / pills: `10px`, or fully round `999px` for chips & tag pills.
- Cards / panels: `16–18px`.
- Tiles: `16–18px`.
- Small inline badges/squares: `8–14px`.
- Team avatar circles: `50%`; team squares (oddíl cards): `11–14px`.

### Shadows
- Card: `0 4px 16px rgba(31,36,48,.05)` (mobile `0 3px 12px`).
- Elevated/hero: `0 6px 22px rgba(31,36,48,.06)` and blue hero `0 6px 22px rgba(42,52,120,.22)`.
- Device/phone frame: `0 18px 50px rgba(31,36,48,.24)`.

### Icons
Simple 2px line icons (stroke `currentColor`), ~15–20px. The mock uses inline SVGs; in
production use the codebase's existing icon set with equivalent glyphs.

---

## Screens / Views

### 1. Nástěnka (Dashboard)
- **Layout:** Blue top app bar (56px) with logo mark + "Bošán" + "NEX" tag, centered search
  pill, avatar. Left sidebar (~172px, white, hairline right border) of nav items; active item
  = yellow-tint bg + blue bold text. Main area is a two-column grid: content column + right
  calendar column (~268px).
- **Components:**
  - **Quick-access tiles** (row of 4): each a rounded tile with a soft tinted background in its
    section colour and a large ŠÁN label, plus a faint oversized circle bleeding off the
    bottom-right corner. Akce=blue tint, Wiki=green tint, Galerie=yellow tint, Databáze=red
    tint. (These section tints are decorative section identity, acceptable since they are not
    per-child-team.)
  - **"Moje akce" / "Volné akce" panels:** white rounded cards, header with ŠÁN title + arrow
    icon, list rows with a small neutral grey dot, bold title, muted date. "Volné akce" ends
    with a yellow pill button "Zobrazit vše".
  - **Calendar card:** white rounded card, ŠÁN month title, weekday row, day grid; today = solid
    blue rounded cell; events render as **named coloured bars** (yellow / blue) spanning the
    row — never empty grey blocks.
- **Key changes from original:** blue header with yellow detail; tinted rounded tiles replace
  hard black-bordered boxes; soft cards replace 2px black borders; calendar events are labelled
  colour bars with today highlighted, and unlabeled grey rectangles are removed.

### 2. Přehled akcí (Events list)
- **Layout:** Same app bar + sidebar (active = "Akce"). Main: ŠÁN H3 "Přehled akcí", a filter
  row (search input + yellow **"Nová akce"** button with + icon), then a table card.
- **Table:** white rounded card; header row on blue-tint bg with uppercase blue labels
  (Název / Termín / Stav / Vedoucí); body rows with alternating zebra (`#fafbfe`); hairline
  dividers.
  - **Stav (status) pills** are colour-coded: "Připravovaná" = blue-tint pill/blue text;
    "Čeká na schválení" = yellow-tint pill/`#b9720f` text.
  - **Vedoucí (leader):** small round initial avatar (in that leader's team colour) + name.
    When there is no leader, show a **red dashed pill "Bez vedoucího"** instead of the confusing
    "Pan NIKDO" placeholder from the original.
- **Key changes:** colour-coded statuses; explicit "Bez vedoucího" task state; leader avatars;
  branded table with blue header, zebra rows and a clear yellow primary action.

### 3. Oddíly / Databáze (Teams / member database)
- **Layout:** app bar + sidebar (active = "Databáze"). Main: header row with ŠÁN "Oddíly" +
  yellow "Nový oddíl" button.
- **Components:**
  - **Hero card "Celá databáze":** full blue rounded card, yellow ŠÁN title, muted-light
    subtitle, large white total count (e.g. 358) with "členů" label, faint yellow circle bleed.
  - **Team grid (3 columns):** white rounded cards, each = a **rounded square team badge in the
    team's colour** showing the team number/letters, then team name (ŠÁN) + "N členů".
    3=green, 4=blue, 5=red, 6=green, 7=neutral grey, KP=ink/black.
- **Key changes:** blue hero with yellow title (core identity); team colour shown as a badge
  (colour = team, not decoration); member count emphasized; yellow action button replaces a
  faint grey text link.

### 4. Detail akce (Event detail) — 5 subpages
Shared shell: app bar + main sidebar (active "Akce") + a **local subnav** column (~150px) with
the event's avatar/title and items Info / Účastníci / Problémy / Účtování / Report (active =
yellow-tint bg, blue bold).

- **4a Info:** center = white card of label/value rows (label in blue bold, value plain, small
  pencil edit icon at row end). "Oddíl" row renders team-colour badges, selected teams in colour
  and unselected greyed. Right column = action buttons stacked (**yellow "Ke schválení"**,
  outline-blue "Do programu", red text "Smazat") above a status card with a blue "Připravovaná"
  header and leader row.
  *Changes:* status as blue bar not grey; actions as clear buttons (yellow/blue/red) not tiny
  top links; rows inside a card; team badges.
- **4b Účastníci:** "Vedoucí" and "Účastníci" sections, each a white card of person rows:
  name + muted "· full name, age", a **team-colour badge**, a **neutral grey role pill**
  (Vedoucí / Instruktor / Dítě — spelled out, not cryptic V/I/D), and a red delete icon.
  "Přidat vedoucí / účastníka" as a clear add action. Right column: "Narozeniny během akce"
  card, "Věk účastníků" bar chart in **blue**, outline-blue "Stáhnout ohlášku" button.
  *Changes:* roles spelled out in neutral colour (colours reserved for teams); team badge on
  each person; branded chart; add = button.
- **4c Problémy:** "Alergie" and "Další problémy" cards; each row shows person + description +
  a status pill at the row (yellow "Nahlášeno" with warning icon / neutral "Bez problémů").
  Right column: "Souhrn" (summary) card with counts. *Changes:* status pill sits with the item
  (not detached at the far right edge); content in cards + summary so the page isn't half-empty.
- **4d Účtování:** "Účtenky" card with receipt rows (code + a **named category chip** e.g.
  "Materiál" + amount + delete icon), "Přidat účtenku" action. Right column: "Výdaje podle typu"
  card with a category legend + proportion bar, and big **"Celkem"** and "Osoba / den" totals in
  blue; outline-blue "Stáhnout účtování". *Changes:* prominent totals; named expense category
  replaces an ambiguous colour stripe.
- **4e Report:** empty-state card (dashed border, doc icon, message, **yellow "Napsat report"**
  button) instead of a bare "Report je prázdný" line; "Fotogalerie" as a clickable card with
  thumbnail icon + title + date + chevron.

### 5. Galerie — album (Photo album detail)
- **Layout:** app bar + sidebar (active "Galerie"). Main: header with ŠÁN album title + actions
  (blue "Publikovat", red "Smazat album"). A white card of label/value rows (Název, Termín,
  **Publikováno → "Nepublikováno" neutral pill**, **Akce → linked chip to the event**, Popis).
  Then "Galerie" heading and an **empty-state upload card** (dashed border, image icon, message,
  yellow **"Nahrát fotky"** upload button).
- **Key changes:** the original "Nahrát fotky" button uses a generic non-brand blue (~`#3b82f6`)
  — **replace with brand yellow/blue**; add a real empty state with icon + CTA; publication
  status as a readable pill (not a dash); linked event as a clickable chip.

### 6. Mobile
Same rules on phones. Blue top bar with yellow logo mark; a **bottom tab bar** whose active
item is brand blue (not generic blue); the same tiles, cards, buttons and team badges as web.
- **Dashboard (mobile):** 2×2 tinted tiles, search field, "Moje akce" card, bottom nav
  (Bošán / Kalendář / Moje).
- **Event detail (mobile):** title + blue status pill, info card of rows, yellow/outline action
  buttons, bottom subnav tabs (Info / Účastníci / Problémy / Účtování / Report).
- **Oddíly (mobile):** yellow + add button, blue "Celá databáze" hero, 2-column team cards with
  colour badges.
- **Album (mobile):** title + "Nepublikováno" pill, info card, empty-state upload card with
  yellow "Nahrát fotky", bottom subnav (Info / Galerie).

---

## Interactions & Behavior
No behavioural changes are proposed — flows, routing, permissions and data stay as in the
current app. Visual-state guidance to preserve/adopt:
- **Active nav** (sidebar, subnav, bottom tabs): yellow-tint bg + blue bold (web) / blue text or
  fill (mobile).
- **Primary buttons** (yellow): use for the main affirmative action per screen (Nová akce, Nový
  oddíl, Ke schválení, Napsat report, Nahrát fotky).
- **Secondary buttons:** outline-blue. **Destructive:** red (text or icon).
- **Status pills:** colour by meaning — blue = in preparation, yellow = needs attention/reported,
  neutral grey = informational/none. Team pills always use the team's colour.
- **Hover/focus** (not depicted): add subtle bg tint / shadow lift consistent with the card
  system; keep within the palette. Define default `a` / `a:hover` in the brand colours (link
  default blue `#2a3478`, hover yellow `#e28f26`).
- **Empty states:** dashed rounded container + line icon + one-line message + a single branded
  CTA button.

## State Management
No new client state introduced by the redesign. Reuse existing state; the only additions are
purely presentational (status → pill colour mapping, team → colour mapping, role → label
mapping). Recommended small lookup maps in the codebase:
- `teamColor[oddíl] → hex` (3→green, 4→blue, 5→red, 6→green, 7→neutral, 22→yellow, KP→ink).
- `statusStyle[stav] → {bg, fg}` (Připravovaná→blue-tint/blue, Čeká na schválení→yellow-tint/#b9720f,
  Nepublikováno→neutral, …).
- `roleLabel[code] → text` (V→Vedoucí, I→Instruktor, D→Dítě).

## Assets
- **Fonts:** ŠÁN (brand display; use real font in production) — mock substitutes **Baloo 2**;
  body **Nunito Sans** (Google Fonts). Swap Baloo 2 → ŠÁN when implementing.
- **Logo:** the round mark (yellow disc + ring) + "Bošán" wordmark + "NEX" tag — use the real
  brand logo asset from the codebase.
- **Icons:** inline line SVGs in the mock; use the codebase's existing icon library.
- **Screenshots:** `before/*.png` are the current live app for reference. No production image
  assets are provided in this bundle.
- **Colour manual:** the group's official manual is the source of truth for exact brand colours
  and the ŠÁN font; defer to it over the hexes here if they differ.

## Files
- `Bošán návrhy.dc.html` — the full before/after review board (all six sections + annotations).
  Open in a browser to see every original vs. proposed screen side by side. This is the primary
  visual reference.
- `before/` — screenshots of the current live app:
  `dashboard.png`, `akce.png`, `oddily.png`, `event.png`, `event-ucastnici.png`,
  `event-problemy.png`, `event-uctovani.png`, `event-report.png`, `gallery.png`,
  `m-dashboard.png`, `m-event.png`, `m-oddily.png`, `m-gallery.png`.
- `after/` — rendered screenshots of the **proposed** design (implementation targets):
  - `01-screen.png` — Nástěnka (dashboard)
  - `02-screen.png` — Přehled akcí (events list)
  - `03-screen.png` — Oddíly / Databáze
  - `04-screen.png` — Detail akce · Info
  - `05-screen.png` — Detail akce · Účastníci
  - `06-screen.png` — Detail akce · Problémy
  - `07-screen.png` — Detail akce · Účtování
  - `08-screen.png` — Detail akce · Report
  - `09-screen.png` — Galerie — album
  - `10-mobile.png` — Mobile: dashboard + event detail
  - `11-mobile.png` — Mobile: oddíly + gallery album
